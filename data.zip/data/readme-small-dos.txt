The files in this directory are a randomly-sampled selection of the original data set given in /home/subjects/comp90049/2014-sm2/project1/. The same terms of use applies to this data; it cannot be reproduced (except for isolated examples) or redistrubuted for any purpose other than this project.

The files training_set_tweets_small.txt and US_small.txt (with the handle to distinguish them from the real data) correspond to a random sampling of roughly 0.1% of the data. Because this is truly random sampling, I can't guarantee that any of the locations are attested in any of the tweets here, which would make actually doing the assignment based on the data (potentially) uninteresting.

The training_set_users_small.txt is the slice of the larger user file that corresponds to the subsampled tweets (i.e. where the User ID from the tweet matches a line in the larger user file).
There are a couple of provisos:
The following users have posted tweets but aren't in the ...users.txt file:
18821815
20890321
36886522
The following users have multiple locations in the ...users.txt file, and I just took the first one (which may not actually be correct):
14386408
14590880
41052407
56502966
